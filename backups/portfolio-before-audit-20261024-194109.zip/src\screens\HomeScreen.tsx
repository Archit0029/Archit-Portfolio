import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Animated,
  Image,
  Linking,
  Modal,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from 'react-native';
import OwnerActionRow from '../components/OwnerActionRow';
import SectionTitle from '../components/SectionTitle';
import { ToastContainer, showToast } from '../components/ToastContainer';
import { EditProfileModal, EditContactModal } from '../components/EditModals';
import { downloadResume, sharePortfolio, sendContactMessage, openProjectLink } from '../utils/buttonHandlers';
import { fetchProfileData, saveProfileData, saveContactData, type ProfileData } from '../services/portfolioService';
import {
  achievements,
  certifications,
  contactDetails,
  education,
  experience,
  interests,
  profile as defaultProfile,
  projects,
  skillGroups,
  socialLinks,
  stats,
} from '../data/portfolio';
import { initialAnalyticsCounts, incrementAnalyticsOnce, type AnalyticsCounts, subscribeToAnalytics } from '../services/analyticsService';
import { darkTheme, lightTheme, type AppTheme, type AppThemeMode } from '../theme/colors';
import { subscribeToPortfolioAccess } from '../services/portfolioAccess';

type ThemeMode = AppThemeMode;

export default function HomeScreen() {
  const { width } = useWindowDimensions();
  const isCompact = width < 720;
  const [themeMode, setThemeMode] = useState<ThemeMode>('dark');
  const [searchQuery, setSearchQuery] = useState('');
  const [typedWord, setTypedWord] = useState('');
  const [typedWordIndex, setTypedWordIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [isOwnerMode, setIsOwnerMode] = useState(false);
  const [isAccessLoading, setIsAccessLoading] = useState(true);
  const [editProfileVisible, setEditProfileVisible] = useState(false);
  const [editContactVisible, setEditContactVisible] = useState(false);
  const [profileImageVisible, setProfileImageVisible] = useState(false);
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactMessage, setContactMessage] = useState('');
  const [isContactSubmitting, setIsContactSubmitting] = useState(false);
  const [analyticsCounts, setAnalyticsCounts] = useState<AnalyticsCounts>(initialAnalyticsCounts);
  const [profile, setProfile] = useState<ProfileData>({
    name: defaultProfile.name,
    title: defaultProfile.title,
    bio: defaultProfile.bio,
    email: defaultProfile.email,
    phone: defaultProfile.phone,
    address: defaultProfile.address,
    image: defaultProfile.image,
    coverImage: defaultProfile.coverImage,
    status: defaultProfile.status,
    university: defaultProfile.university,
    completion: defaultProfile.completion,
  });
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.96)).current;
  const profileImageFadeAnim = useRef(new Animated.Value(0)).current;
  const profileImageScaleAnim = useRef(new Animated.Value(0.92)).current;

  const theme = themeMode === 'dark' ? darkTheme : lightTheme;
  const canEdit = !isAccessLoading && isOwnerMode;
  const noop = () => undefined;

  useEffect(() => {
    const loadProfileData = async () => {
      try {
        const profileData = await fetchProfileData();
        setProfile(profileData);
      } catch (error) {
        console.error('Error loading profile:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadProfileData();

    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 700,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 700,
        useNativeDriver: true,
      }),
    ]).start();
  }, [fadeAnim, scaleAnim]);

  useEffect(() => {
    const words = ['Developer.', 'Builder.', 'Creator.'];
    const word = words[typedWordIndex];
    const isComplete = typedWord === word;
    const timeout = setTimeout(() => {
      if (isComplete) {
        setTypedWord('');
        setTypedWordIndex((index) => (index + 1) % words.length);
      } else {
        setTypedWord(word.slice(0, typedWord.length + 1));
      }
    }, isComplete ? 1800 : 80);

    return () => clearTimeout(timeout);
  }, [typedWord, typedWordIndex]);

  useEffect(() => {
    const unsubscribe = subscribeToPortfolioAccess((state) => {
      setIsOwnerMode(state.isOwner);
      setIsAccessLoading(state.isLoading);
    });

    return unsubscribe;
  }, []);

  useEffect(() => {
    const unsubscribe = subscribeToAnalytics(setAnalyticsCounts);
    void incrementAnalyticsOnce('visits', 'visit');
    void incrementAnalyticsOnce('profileViews', 'profile-view');
    return unsubscribe;
  }, []);

  const closeProfileImage = () => {
    Animated.parallel([
      Animated.timing(profileImageFadeAnim, {
        toValue: 0,
        duration: 180,
        useNativeDriver: true,
      }),
      Animated.timing(profileImageScaleAnim, {
        toValue: 0.92,
        duration: 180,
        useNativeDriver: true,
      }),
    ]).start(() => setProfileImageVisible(false));
  };

  const openProfileImage = () => {
    setProfileImageVisible(true);
    profileImageFadeAnim.setValue(0);
    profileImageScaleAnim.setValue(0.92);
    Animated.parallel([
      Animated.timing(profileImageFadeAnim, {
        toValue: 1,
        duration: 220,
        useNativeDriver: true,
      }),
      Animated.spring(profileImageScaleAnim, {
        toValue: 1,
        damping: 18,
        stiffness: 180,
        mass: 0.8,
        useNativeDriver: true,
      }),
    ]).start();
  };

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && profileImageVisible) {
        closeProfileImage();
      }
    };

    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, [profileImageVisible]);

  const filteredProjects = useMemo(() => {
    const query = searchQuery.toLowerCase();
    if (!query) return projects;

    return projects.filter((project) => {
      const haystack = `${project.title} ${project.description} ${project.tags.join(' ')}`.toLowerCase();
      return haystack.includes(query);
    });
  }, [searchQuery]);

  const filteredSkills = useMemo(() => {
    const query = searchQuery.toLowerCase();
    if (!query) return skillGroups;

    return skillGroups.filter((group) => {
      const haystack = `${group.title} ${group.items.join(' ')}`.toLowerCase();
      return haystack.includes(query);
    });
  }, [searchQuery]);

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      const profileData = await fetchProfileData();
      setProfile(profileData);
    } catch (error) {
      console.error('Error refreshing profile:', error);
    } finally {
      setTimeout(() => setRefreshing(false), 700);
    }
  };

  const openLink = (url: string) => {
    Linking.openURL(url);
  };

  const handleDownloadResume = async () => {
    await downloadResume();
  };

  const handleSharePortfolio = async () => {
    await sharePortfolio();
  };

  const handleContactSubmit = async () => {
    setIsContactSubmitting(true);
    const success = await sendContactMessage(contactName, contactEmail, contactMessage, profile.email);
    if (success) {
      setContactName('');
      setContactEmail('');
      setContactMessage('');
    }
    setIsContactSubmitting(false);
  };

  const handleSaveProfile = async (data: { name: string; title: string; bio: string }) => {
    try {
      await saveProfileData(data);
      setProfile(prev => ({
        ...prev,
        ...data,
      }));
      setEditProfileVisible(false);
      showToast('Profile updated successfully!', 'success');
    } catch (error) {
      console.error('Error saving profile:', error);
      showToast('Failed to save profile. Please try again.', 'error');
    }
  };

  const handleSaveContact = async (data: { email: string; phone: string; address: string }) => {
    try {
      await saveContactData(data);
      setProfile(prev => ({
        ...prev,
        ...data,
      }));
      setEditContactVisible(false);
      showToast('Contact info updated successfully!', 'success');
    } catch (error) {
      console.error('Error saving contact:', error);
      showToast('Failed to save contact info. Please try again.', 'error');
    }
  };

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: theme.background }]}
      contentContainerStyle={styles.content}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.accent} colors={[theme.accent]} />}
    >
      <View style={styles.topBar}>
        <View style={styles.brandLockup}>
          <Text style={[styles.brandLogo, { color: theme.textPrimary }]}><Text style={{ color: theme.accent }}>A</Text><Text style={{ color: theme.accent }}>B</Text><Text style={{ color: theme.accentSoft }}>_</Text></Text>
          <Text style={[styles.brandText, { color: theme.textSecondary }]}>DIGITAL STUDIO / 2026</Text>
        </View>
        <View style={[styles.navLinks, isCompact && styles.navLinksCompact]}>
          {['About', 'Skills', 'Work', 'Contact'].map((label) => <Text key={label} style={[styles.navLink, { color: theme.textSecondary }]}>{label}</Text>)}
        </View>
        <View style={styles.toggleRow}>
          <Text style={[styles.toggleLabel, { color: theme.textSecondary }]}>MODE</Text>
          <Switch value={themeMode === 'dark'} onValueChange={() => setThemeMode(themeMode === 'dark' ? 'light' : 'dark')} thumbColor={themeMode === 'dark' ? theme.accent : theme.surface} trackColor={{ false: theme.border, true: theme.accentSoft }} />
        </View>
      </View>

      {canEdit ? (
        <View style={[styles.ownerPanel, { backgroundColor: theme.surface, borderColor: theme.border }]}> 
          <Text style={[styles.ownerPanelTitle, { color: theme.textPrimary }]}>Owner mode</Text>
          <Text style={[styles.ownerPanelText, { color: theme.textSecondary }]}>Only you can manage portfolio content.</Text>
          <OwnerActionRow
            theme={theme}
            actions={[
              { label: 'Edit Profile', onPress: () => setEditProfileVisible(true) },
              { label: 'Edit Cover', onPress: () => showToast('Cover upload coming soon', 'info') },
              { label: 'Upload Resume', onPress: () => showToast('Resume upload coming soon', 'info') },
              { label: 'Update Social', onPress: () => showToast('Social links update coming soon', 'info') },
              { label: 'Update Contact', onPress: () => setEditContactVisible(true) },
            ]}
          />
        </View>
      ) : null}

      <Animated.View style={[styles.heroCard, { opacity: fadeAnim, transform: [{ scale: scaleAnim }] }]}>
        <Image source={{ uri: profile.coverImage }} style={styles.coverImage} />
        <View style={[styles.coverOverlay, { backgroundColor: theme.overlay }]} />
        {canEdit ? (
          <Pressable style={[styles.imageEditButton, { backgroundColor: theme.surfaceAlt }]} onPress={() => showToast('Cover image upload coming soon', 'info')}> 
            <Text style={styles.imageEditText}>✎</Text>
          </Pressable>
        ) : null}
        <View style={styles.heroContent}>
          <View style={styles.heroKicker}>
            <View style={[styles.pingDot, { backgroundColor: theme.accent }]} />
            <Text style={[styles.eyebrow, { color: theme.accent }]}>Available for opportunities / 2026</Text>
          </View>
          <View style={styles.profileHeader}>
            <View style={styles.avatarWrapper}>
              <Pressable onPress={openProfileImage} accessibilityRole="button" accessibilityLabel="View profile picture">
                <Image source={{ uri: profile.image }} style={styles.avatar} />
              </Pressable>
              {canEdit ? (
                <Pressable style={[styles.avatarEditButton, { backgroundColor: theme.surfaceAlt }]} onPress={() => showToast('Avatar image upload coming soon', 'info')}> 
                  <Text style={styles.imageEditText}>✎</Text>
                </Pressable>
              ) : null}
            </View>
            <View style={styles.profileMeta}>
              <Text style={[styles.heading, { color: theme.textPrimary }]}>{profile.name.split(' ')[0]}</Text>
              <Text style={[styles.headingAccent, { color: theme.accentSoft }]}>{profile.name.split(' ').slice(1).join(' ')}</Text>
              <Text style={[styles.title, { color: theme.textSecondary }]}>{profile.title}</Text>
              <View style={[styles.statusPill, { backgroundColor: theme.surfaceAlt }]}> 
                <Text style={[styles.statusText, { color: theme.textPrimary }]}>{profile.status}</Text>
              </View>
            </View>
          </View>

          <Text style={[styles.description, { color: theme.textPrimary }]}>{profile.bio}</Text>
          <Text style={[styles.cursorLine, { color: theme.accent }]}>Full-Stack {typedWord}<Text style={{ color: theme.accentSoft }}> |</Text></Text>

          <View style={[styles.progressCard, { backgroundColor: theme.surfaceAlt, borderColor: theme.border }]}> 
            <View style={styles.progressRow}>
              <Text style={[styles.progressLabel, { color: theme.textPrimary }]}>Profile completion</Text>
              <Text style={[styles.progressValue, { color: theme.accent }]}>{profile.completion}%</Text>
            </View>
            <View style={[styles.progressBar, { backgroundColor: theme.border }]}> 
              <View style={[styles.progressFill, { width: `${profile.completion}%`, backgroundColor: theme.accent }]} />
            </View>
          </View>

          <View style={styles.actionRow}>
            <Pressable style={({ pressed }) => [styles.primaryButton, { backgroundColor: theme.accent, opacity: pressed ? 0.8 : 1 }]} onPress={handleDownloadResume}>
              <Text style={styles.buttonText}>Download resume  ↗</Text>
            </Pressable>
            <Pressable style={({ pressed }) => [styles.secondaryButton, { borderColor: theme.border, backgroundColor: pressed ? theme.surfaceAlt : 'transparent' }]} onPress={handleSharePortfolio}>
              <Text style={[styles.secondaryButtonText, { color: theme.textPrimary }]}>Share portfolio</Text>
            </Pressable>
          </View>
          <View style={styles.scrollCue}>
            <Text style={[styles.scrollCueLabel, { color: theme.textSecondary }]}>SCROLL TO EXPLORE</Text>
            <View style={[styles.scrollCueLine, { backgroundColor: theme.accent }]} />
          </View>
          {canEdit ? (
            <OwnerActionRow
              theme={theme}
              actions={[
                { label: 'Edit Profile', onPress: () => setEditProfileVisible(true) },
                { label: 'Save Changes', onPress: () => showToast('All changes saved', 'success') },
              ]}
            />
          ) : null}
        </View>
        <View pointerEvents="none" style={styles.orbitDecoration}>
          <View style={[styles.orbitRing, styles.orbitRingLarge, { borderColor: theme.border }]} />
          <View style={[styles.orbitRing, styles.orbitRingMedium, { borderColor: theme.accentSoft }]} />
          <View style={[styles.orbitRing, styles.orbitRingSmall, { borderColor: theme.accent }]} />
          <Text style={[styles.orbitCode, { color: theme.accent }]}> &lt;/&gt; </Text>
        </View>
      </Animated.View>

      <View style={[styles.marqueeBand, { backgroundColor: theme.surface, borderColor: theme.border }]}>
        <Text style={[styles.marqueeText, { color: theme.textSecondary }]}>REACT  ✦  FIREBASE  ✦  JAVASCRIPT  ✦  FLUTTER  ✦  TYPESCRIPT  ✦  SYSTEMS  ✦  PRODUCT THINKING</Text>
      </View>

      <View style={styles.statsRow}>
        {stats.map((stat) => (
          <View key={stat.label} style={[styles.statCard, { backgroundColor: theme.surface, borderColor: theme.border }]}> 
            <Text style={[styles.statValue, { color: theme.textPrimary }]}>{stat.value}</Text>
            <Text style={[styles.statLabel, { color: theme.textSecondary }]}>{stat.label}</Text>
          </View>
        ))}
      </View>

      <View style={styles.section}>
        <SectionTitle title="Index / Search" subtitle="Find projects, skills, education, and experience instantly." theme={theme} />
        <TextInput
          value={searchQuery}
          onChangeText={setSearchQuery}
          placeholder="Search projects or skills"
          placeholderTextColor={theme.muted}
          style={[styles.searchInput, { backgroundColor: theme.surface, borderColor: theme.border, color: theme.textPrimary }]}
        />
      </View>

      <View style={styles.section}>
        <SectionTitle title="01 / About Me" subtitle="A complete snapshot of your professional identity." theme={theme} />
        <View style={[styles.detailCard, { backgroundColor: theme.surface, borderColor: theme.border }]}> 
          <View style={styles.detailGrid}>
            {[
              ['Email', profile.email],
              ['Phone', profile.phone],
              ['Location', profile.address],
              ['University', profile.university],
            ].map(([label, value]) => (
              <View key={label} style={styles.detailItem}>
                <Text style={[styles.detailLabel, { color: theme.textSecondary }]}>{label}</Text>
                <Text style={[styles.detailValue, { color: theme.textPrimary }]}>{value}</Text>
              </View>
            ))}
          </View>
        </View>
      </View>

      <View style={styles.section}>
        <SectionTitle title="Education" subtitle="Academic milestones and achievements in a timeline." theme={theme} />
        {canEdit ? (
          <OwnerActionRow theme={theme} actions={[{ label: 'Add Education', onPress: () => showToast('Education management coming soon', 'info') }, { label: 'Edit Education', onPress: () => showToast('Education management coming soon', 'info') }, { label: 'Delete Education', onPress: () => showToast('Education management coming soon', 'info') }]} />
        ) : null}
        {education.map((item) => (
          <View key={item.degree} style={[styles.card, { backgroundColor: theme.surface, borderColor: theme.border }]}> 
            <Text style={[styles.cardTitle, { color: theme.textPrimary }]}>{item.institution}</Text>
            <Text style={[styles.cardMeta, { color: theme.accent }]}>{item.degree}</Text>
            <Text style={[styles.cardMeta, { color: theme.textSecondary }]}>{item.period}</Text>
            <Text style={[styles.cardDescription, { color: theme.textSecondary }]}>{item.description}</Text>
          </View>
        ))}
      </View>

      <View style={styles.section}>
        <SectionTitle title="Skills" subtitle="Carefully grouped expertise for modern product teams." theme={theme} />
        {canEdit ? (
          <OwnerActionRow theme={theme} actions={[{ label: 'Add Skills', onPress: () => showToast('Skills management coming soon', 'info') }, { label: 'Edit Skills', onPress: () => showToast('Skills management coming soon', 'info') }, { label: 'Delete Skills', onPress: () => showToast('Skills management coming soon', 'info') }]} />
        ) : null}
        <View style={styles.skillGroups}>
          {filteredSkills.map((group) => (
            <View key={group.title} style={[styles.skillGroupCard, { backgroundColor: theme.surface, borderColor: theme.border }]}> 
              <Text style={[styles.skillGroupTitle, { color: group.accent }]}>{group.title}</Text>
              <View style={styles.skillGrid}>
                {group.items.map((skill) => (
                  <View key={skill} style={[styles.skillChip, { backgroundColor: theme.surfaceAlt }]}> 
                    <Text style={[styles.skillText, { color: theme.textPrimary }]}>{skill}</Text>
                  </View>
                ))}
              </View>
            </View>
          ))}
        </View>
        <View style={[styles.skillBars, { backgroundColor: theme.surface, borderColor: theme.border }]}>
          {[
            ['Frontend systems', 92],
            ['Firebase architecture', 86],
            ['Mobile development', 78],
            ['Product thinking', 88],
          ].map(([label, value]) => (
            <View key={label as string} style={styles.skillBarRow}>
              <View style={styles.skillBarMeta}>
                <Text style={[styles.skillBarLabel, { color: theme.textPrimary }]}>{label}</Text>
                <Text style={[styles.skillBarValue, { color: theme.accent }]}>{value}%</Text>
              </View>
              <View style={[styles.skillBarTrack, { backgroundColor: theme.border }]}>
                <View style={[styles.skillBarFill, { width: `${value}%`, backgroundColor: theme.accent }]} />
              </View>
            </View>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <SectionTitle title="Experience" subtitle="Roles that shaped my product and engineering practice." theme={theme} />
        {canEdit ? (
          <OwnerActionRow theme={theme} actions={[{ label: 'Add Experience', onPress: () => showToast('Experience management coming soon', 'info') }, { label: 'Edit Experience', onPress: () => showToast('Experience management coming soon', 'info') }, { label: 'Delete Experience', onPress: () => showToast('Experience management coming soon', 'info') }]} />
        ) : null}
        {experience.map((item) => (
          <View key={item.role} style={[styles.card, { backgroundColor: theme.surface, borderColor: theme.border }]}> 
            <Text style={[styles.cardTitle, { color: theme.textPrimary }]}>{item.company}</Text>
            <Text style={[styles.cardMeta, { color: theme.accent }]}>{item.role}</Text>
            <Text style={[styles.cardMeta, { color: theme.textSecondary }]}>{item.type} • {item.period}</Text>
            <Text style={[styles.cardDescription, { color: theme.textSecondary }]}>{item.description}</Text>
            <View style={styles.tagRow}>
              {item.stack.map((tool) => (
                <View key={tool} style={[styles.tagChip, { backgroundColor: theme.surfaceAlt }]}> 
                  <Text style={[styles.tagText, { color: theme.textPrimary }]}>{tool}</Text>
                </View>
              ))}
            </View>
          </View>
        ))}
      </View>

      <View style={styles.section}>
        <SectionTitle title="03 / Selected Work" subtitle="Recent work designed for impact and user delight." theme={theme} />
        {canEdit ? (
          <OwnerActionRow theme={theme} actions={[{ label: 'Add Project', onPress: () => showToast('Project management coming soon', 'info') }, { label: 'Edit Project', onPress: () => showToast('Project management coming soon', 'info') }, { label: 'Delete Project', onPress: () => showToast('Project management coming soon', 'info') }]} />
        ) : null}
        <View style={styles.projectGrid}>
        {filteredProjects.map((project, index) => (
          <View key={project.title} style={[styles.card, styles.projectCard, { backgroundColor: theme.surface, borderColor: theme.border }]}> 
            <Text style={[styles.projectNumber, { color: index === 2 ? '#f97316' : theme.accent }]}>0{index + 1}</Text>
            <Text style={[styles.cardTitle, { color: theme.textPrimary }]}>{project.title}</Text>
            <Text style={[styles.cardDescription, { color: theme.textSecondary }]}>{project.description}</Text>
            <Text style={[styles.highlightText, { color: theme.accent }]}>{project.highlight}</Text>
            <View style={styles.tagRow}>
              {project.tags.map((tag) => (
                <View key={tag} style={[styles.tagChip, { backgroundColor: theme.surfaceAlt }]}> 
                  <Text style={[styles.tagText, { color: theme.textPrimary }]}>{tag}</Text>
                </View>
              ))}
            </View>
            <View style={styles.actionRow}>
              <Pressable onPress={() => openLink(project.github ?? project.link)}>
                <Text style={[styles.linkText, { color: theme.accent }]}>GitHub</Text>
              </Pressable>
              <Pressable onPress={() => openLink(project.demo ?? project.link)}>
                <Text style={[styles.linkText, { color: theme.accent }]}>Live demo</Text>
              </Pressable>
            </View>
          </View>
        ))}
        </View>
      </View>

      <View style={styles.section}>
        <SectionTitle title="Certifications" subtitle="Verified credentials and learning milestones." theme={theme} />
        {canEdit ? (
          <OwnerActionRow theme={theme} actions={[{ label: 'Add Certificate', onPress: () => showToast('Certificate management coming soon', 'info') }, { label: 'Edit Certificates', onPress: () => showToast('Certificate management coming soon', 'info') }, { label: 'Delete Certificates', onPress: () => showToast('Certificate management coming soon', 'info') }]} />
        ) : null}
        {certifications.map((item) => (
          <View key={item.name} style={[styles.card, { backgroundColor: theme.surface, borderColor: theme.border }]}> 
            <Text style={[styles.cardTitle, { color: theme.textPrimary }]}>{item.name}</Text>
            <Text style={[styles.cardMeta, { color: theme.textSecondary }]}>{item.issuer} • {item.date}</Text>
            <Text style={[styles.cardDescription, { color: theme.textSecondary }]}>Credential ID: {item.credential}</Text>
          </View>
        ))}
      </View>

      <View style={[styles.footer, { borderTopColor: theme.border }]}> 
        <Text style={[styles.footerText, { color: theme.textSecondary }]}>© 2026 ARCHIT BISHNOI / BUILT WITH INTENT</Text>
        <View style={styles.footerStatus}>
          <View style={[styles.pingDot, { backgroundColor: theme.accent }]} />
          <Text style={[styles.footerText, { color: theme.accent }]}>OPEN TO OPPORTUNITIES</Text>
        </View>
      </View>

      <View style={styles.section}>
        <SectionTitle title="Achievements" subtitle="Recognitions that reflect my dedication and craft." theme={theme} />
        <View style={styles.achievementGrid}>
          {achievements.map((item) => (
            <View key={item.title} style={[styles.card, { backgroundColor: theme.surface, borderColor: theme.border }]}> 
              <Text style={[styles.cardTitle, { color: theme.textPrimary }]}>{item.title}</Text>
              <Text style={[styles.cardDescription, { color: theme.textSecondary }]}>{item.detail}</Text>
            </View>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <SectionTitle title="Hobbies & interests" subtitle="Interests that bring balance beyond the screen." theme={theme} />
        <View style={styles.hobbyGrid}>
          {interests.map((item) => (
            <View key={item.label} style={[styles.hobbyChip, { backgroundColor: theme.surfaceAlt }]}> 
              <Text style={styles.hobbyIcon}>{item.icon}</Text>
              <Text style={[styles.hobbyText, { color: theme.textPrimary }]}>{item.label}</Text>
            </View>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <SectionTitle title="Social links" subtitle="Open the channels where my work and ideas live." theme={theme} />
        <View style={styles.socialRow}>
          {socialLinks.map((item) => (
            <Pressable key={item.label} onPress={() => openLink(item.url)} style={[styles.socialChip, { backgroundColor: theme.surface, borderColor: theme.border }]}>
              <Text style={[styles.socialText, { color: theme.textPrimary }]}>{item.icon}</Text>
              <Text style={[styles.socialText, { color: theme.textPrimary }]}>{item.label}</Text>
            </Pressable>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <SectionTitle title="05 / Contact" subtitle="Let’s build something meaningful together." theme={theme} />
        <View style={[styles.contactCard, { backgroundColor: theme.surface, borderColor: theme.border }]}>
          <View style={styles.contactInfo}>
            <Text style={[styles.cardTitle, { color: theme.textPrimary }]}>{contactDetails.email}</Text>
            <Text style={[styles.cardDescription, { color: theme.textSecondary }]}>{contactDetails.phone}</Text>
            <Text style={[styles.cardDescription, { color: theme.textSecondary }]}>{contactDetails.address}</Text>
          </View>

          <View style={[styles.contactFormDivider, { backgroundColor: theme.border }]} />

          <View style={styles.contactForm}>
            <Text style={[styles.formLabel, { color: theme.textPrimary }]}>Send me a message</Text>
            
            <TextInput
              style={[styles.formInput, { backgroundColor: theme.surfaceAlt, borderColor: theme.border, color: theme.textPrimary }]}
              placeholder="Your name"
              placeholderTextColor={theme.muted}
              value={contactName}
              onChangeText={setContactName}
              editable={!isContactSubmitting}
            />
            
            <TextInput
              style={[styles.formInput, { backgroundColor: theme.surfaceAlt, borderColor: theme.border, color: theme.textPrimary }]}
              placeholder="your@email.com"
              placeholderTextColor={theme.muted}
              value={contactEmail}
              onChangeText={setContactEmail}
              keyboardType="email-address"
              editable={!isContactSubmitting}
            />
            
            <TextInput
              style={[styles.formTextArea, { backgroundColor: theme.surfaceAlt, borderColor: theme.border, color: theme.textPrimary }]}
              placeholder="Your message..."
              placeholderTextColor={theme.muted}
              value={contactMessage}
              onChangeText={setContactMessage}
              multiline
              numberOfLines={4}
              editable={!isContactSubmitting}
            />
            
            <Pressable
              style={[styles.submitButton, { backgroundColor: theme.accent, opacity: isContactSubmitting ? 0.6 : 1 }]}
              onPress={handleContactSubmit}
              disabled={isContactSubmitting}
            >
              <Text style={styles.submitButtonText}>{isContactSubmitting ? 'Sending...' : 'Send Message'}</Text>
            </Pressable>
          </View>
        </View>
      </View>

      <View style={styles.section}>
        <SectionTitle title="Visitor analytics" subtitle="A quick glance at portfolio performance." theme={theme} />
        <View style={styles.analyticsGrid}>
          {[
            { label: 'Visitors', value: analyticsCounts.visits },
            { label: 'Portfolio views', value: analyticsCounts.profileViews },
            { label: 'Resume downloads', value: analyticsCounts.downloads },
            { label: 'Shares', value: analyticsCounts.shares },
          ].map((item) => (
            <View key={item.label} style={[styles.statCard, { backgroundColor: theme.surface, borderColor: theme.border }]}> 
              <Text style={[styles.statValue, { color: theme.textPrimary }]}>{item.value}</Text>
              <Text style={[styles.statLabel, { color: theme.textSecondary }]}>{item.label}</Text>
            </View>
          ))}
        </View>
      </View>

      {canEdit ? (
        <Pressable style={[styles.fab, { backgroundColor: theme.accent }]} onPress={() => showToast('Add new item - coming soon', 'info')}> 
          <Text style={styles.fabText}>+</Text>
        </Pressable>
      ) : null}
      
      <ToastContainer theme={theme} />
      
      <EditProfileModal
        visible={editProfileVisible}
        onClose={() => setEditProfileVisible(false)}
        theme={theme}
        onSave={handleSaveProfile}
        initialData={{ name: profile.name, title: profile.title, bio: profile.bio }}
      />
      
      <EditContactModal
        visible={editContactVisible}
        onClose={() => setEditContactVisible(false)}
        theme={theme}
        onSave={handleSaveContact}
        initialData={{ email: profile.email, phone: profile.phone, address: profile.address }}
      />

      <Modal
        visible={profileImageVisible}
        transparent
        animationType="none"
        statusBarTranslucent
        onRequestClose={closeProfileImage}
      >
        <Animated.View style={[styles.profileImageModal, { opacity: profileImageFadeAnim }]}>
          <Pressable style={styles.profileImageBackdrop} onPress={closeProfileImage} />
          <Animated.View style={[styles.profileImageFrame, { transform: [{ scale: profileImageScaleAnim }] }]}>
            <Image source={{ uri: profile.image }} style={styles.profileImageLarge} resizeMode="contain" />
          </Animated.View>
          <Pressable
            style={styles.profileImageCloseButton}
            onPress={closeProfileImage}
            accessibilityRole="button"
            accessibilityLabel="Close profile picture"
          >
            <Text style={styles.profileImageCloseText}>×</Text>
          </Pressable>
        </Animated.View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 24,
    paddingTop: 18,
    paddingBottom: 96,
    maxWidth: 1180,
    width: '100%',
    alignSelf: 'center',
  },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 34,
    borderBottomWidth: 1,
    paddingBottom: 16,
    borderBottomColor: '#1e1e2e',
  },
  brandLockup: {
    gap: 3,
  },
  brandLogo: {
    fontFamily: 'JetBrains Mono',
    fontSize: 22,
    fontWeight: '700',
    letterSpacing: 1,
  },
  brandIndex: {
    fontSize: 11,
    letterSpacing: 2,
    fontWeight: '700',
  },
  brandText: {
    fontFamily: 'JetBrains Mono',
    fontSize: 13,
    letterSpacing: 2,
    fontWeight: '700',
  },
  navLinks: {
    flexDirection: 'row',
    gap: 22,
    marginLeft: 'auto',
    marginRight: 28,
  },
  navLinksCompact: {
    display: 'none',
  },
  navLink: {
    fontFamily: 'JetBrains Mono',
    fontSize: 11,
    textTransform: 'uppercase',
    letterSpacing: 1.1,
  },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  toggleLabel: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1.4,
  },
  heroCard: {
    borderRadius: 0,
    overflow: 'hidden',
    marginBottom: 28,
    borderWidth: 1,
    borderColor: '#1e1e2e',
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.16,
    shadowRadius: 22,
    elevation: 5,
  },
  orbitDecoration: {
    position: 'absolute',
    right: 66,
    top: 92,
    width: 290,
    height: 290,
    alignItems: 'center',
    justifyContent: 'center',
    opacity: 0.78,
  },
  orbitRing: {
    position: 'absolute',
    borderRadius: 999,
    borderWidth: 1,
  },
  orbitRingLarge: {
    width: 290,
    height: 290,
  },
  orbitRingMedium: {
    width: 210,
    height: 210,
  },
  orbitRingSmall: {
    width: 128,
    height: 128,
  },
  orbitCode: {
    fontFamily: 'JetBrains Mono',
    fontSize: 24,
    fontWeight: '700',
  },
  scrollCue: {
    alignItems: 'center',
    marginTop: 28,
  },
  scrollCueLabel: {
    fontFamily: 'JetBrains Mono',
    fontSize: 9,
    letterSpacing: 1.5,
  },
  scrollCueLine: {
    width: 1,
    height: 30,
    marginTop: 8,
    opacity: 0.7,
  },
  marqueeBand: {
    borderTopWidth: 1,
    borderBottomWidth: 1,
    paddingVertical: 14,
    marginBottom: 42,
    overflow: 'hidden',
  },
  marqueeText: {
    fontFamily: 'JetBrains Mono',
    fontSize: 10,
    letterSpacing: 1.5,
    textAlign: 'center',
  },
  ownerPanel: {
    borderRadius: 20,
    borderWidth: 1,
    padding: 12,
    marginBottom: 12,
  },
  ownerPanelTitle: {
    fontSize: 14,
    fontWeight: '800',
    marginBottom: 4,
  },
  ownerPanelText: {
    fontSize: 12,
    marginBottom: 8,
  },
  coverImage: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    height: 280,
  },
  coverOverlay: {
    ...StyleSheet.absoluteFill,
  },
  heroContent: {
    padding: 28,
    paddingTop: 34,
    minHeight: 490,
    justifyContent: 'flex-end',
  },
  heroKicker: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 22,
  },
  pingDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 16,
    marginBottom: 20,
  },
  avatarWrapper: {
    position: 'relative',
  },
  avatar: {
    width: 72,
    height: 72,
    borderRadius: 0,
    borderWidth: 1,
    borderColor: '#22d3ee',
  },
  profileImageModal: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.82)',
  },
  profileImageBackdrop: {
    ...StyleSheet.absoluteFill,
  },
  profileImageFrame: {
    width: '92%',
    height: '78%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  profileImageLarge: {
    width: '100%',
    height: '100%',
  },
  profileImageCloseButton: {
    position: 'absolute',
    top: 20,
    right: 20,
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 22,
    backgroundColor: 'rgba(0,0,0,0.56)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  profileImageCloseText: {
    color: '#ffffff',
    fontSize: 30,
    fontWeight: '300',
    lineHeight: 32,
  },
  avatarEditButton: {
    position: 'absolute',
    right: -4,
    bottom: -2,
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  imageEditButton: {
    position: 'absolute',
    top: 12,
    right: 12,
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 2,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  imageEditText: {
    fontSize: 12,
    fontWeight: '800',
  },
  profileMeta: {
    flex: 1,
  },
  eyebrow: {
    fontSize: 10,
    letterSpacing: 2,
    textTransform: 'uppercase',
    fontWeight: '700',
    marginBottom: 4,
  },
  heading: {
    fontFamily: 'Fraunces',
    fontSize: 54,
    fontWeight: '800',
    lineHeight: 56,
    marginBottom: 0,
    letterSpacing: 0,
  },
  headingAccent: {
    fontFamily: 'Fraunces',
    fontSize: 54,
    fontWeight: '800',
    lineHeight: 56,
    marginBottom: 6,
  },
  title: {
    fontFamily: 'Outfit',
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 8,
  },
  statusPill: {
    alignSelf: 'flex-start',
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  description: {
    fontFamily: 'Outfit',
    fontSize: 15,
    lineHeight: 24,
    marginBottom: 18,
    maxWidth: 720,
  },
  cursorLine: {
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1,
    marginBottom: 18,
  },
  progressCard: {
    borderRadius: 0,
    padding: 14,
    borderWidth: 1,
    marginBottom: 14,
  },
  progressRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  progressLabel: {
    fontFamily: 'JetBrains Mono',
    fontSize: 13,
    fontWeight: '600',
  },
  progressValue: {
    fontFamily: 'JetBrains Mono',
    fontSize: 13,
    fontWeight: '700',
  },
  progressBar: {
    height: 8,
    borderRadius: 999,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 999,
  },
  actionRow: {
    flexDirection: 'row',
    gap: 10,
    flexWrap: 'wrap',
  },
  primaryButton: {
    borderRadius: 0,
    paddingVertical: 13,
    paddingHorizontal: 16,
  },
  secondaryButton: {
    borderRadius: 0,
    paddingVertical: 13,
    paddingHorizontal: 16,
    borderWidth: 1,
  },
  buttonText: {
    fontFamily: 'JetBrains Mono',
    color: '#ffffff',
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  secondaryButtonText: {
    fontFamily: 'JetBrains Mono',
    fontWeight: '700',
  },
  statsRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 30,
    flexWrap: 'wrap',
  },
  statCard: {
    flexBasis: '31%',
    minWidth: 100,
    borderRadius: 0,
    padding: 14,
    borderWidth: 1,
    minHeight: 82,
  },
  statValue: {
    fontFamily: 'Fraunces',
    fontSize: 18,
    fontWeight: '700',
  },
  statLabel: {
    fontFamily: 'JetBrains Mono',
    fontSize: 12,
    marginTop: 4,
  },
  section: {
    marginBottom: 42,
  },
  searchInput: {
    borderWidth: 1,
    borderRadius: 0,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
  },
  detailCard: {
    borderRadius: 0,
    padding: 16,
    borderWidth: 1,
  },
  detailGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  detailItem: {
    width: '48%',
  },
  detailLabel: {
    fontFamily: 'JetBrains Mono',
    fontSize: 12,
    marginBottom: 4,
  },
  detailValue: {
    fontFamily: 'Outfit',
    fontSize: 14,
    fontWeight: '600',
  },
  card: {
    borderRadius: 0,
    padding: 16,
    borderWidth: 1,
    marginBottom: 1,
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 10,
    elevation: 2,
  },
  cardTitle: {
    fontFamily: 'Fraunces',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  cardMeta: {
    fontFamily: 'JetBrains Mono',
    fontSize: 13,
    marginBottom: 2,
  },
  cardDescription: {
    fontFamily: 'Outfit',
    fontSize: 14,
    lineHeight: 21,
    marginTop: 6,
  },
  highlightText: {
    marginTop: 6,
    fontSize: 13,
    fontWeight: '600',
  },
  tagRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 10,
  },
  tagChip: {
    borderRadius: 0,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  tagText: {
    fontFamily: 'JetBrains Mono',
    fontSize: 12,
    fontWeight: '600',
  },
  linkText: {
    fontFamily: 'JetBrains Mono',
    fontSize: 13,
    fontWeight: '700',
  },
  skillGroups: {
    gap: 12,
  },
  skillBars: {
    borderWidth: 1,
    padding: 16,
    marginTop: 12,
    gap: 16,
  },
  skillBarRow: {
    gap: 7,
  },
  skillBarMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  skillBarLabel: {
    fontFamily: 'JetBrains Mono',
    fontSize: 11,
    textTransform: 'uppercase',
    letterSpacing: 0.7,
  },
  skillBarValue: {
    fontFamily: 'JetBrains Mono',
    fontSize: 11,
  },
  skillBarTrack: {
    height: 2,
    overflow: 'hidden',
  },
  skillBarFill: {
    height: '100%',
  },
  skillGroupCard: {
    borderRadius: 0,
    padding: 14,
    borderWidth: 1,
  },
  projectGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 1,
    backgroundColor: '#1e1e2e',
  },
  projectCard: {
    flexBasis: '49.8%',
    flexGrow: 1,
    minWidth: 280,
    marginBottom: 0,
    minHeight: 230,
  },
  projectNumber: {
    fontFamily: 'Fraunces',
    fontSize: 52,
    lineHeight: 58,
    opacity: 0.18,
    marginBottom: 8,
  },
  skillGroupTitle: {
    fontFamily: 'JetBrains Mono',
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 8,
  },
  skillGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  skillChip: {
    borderRadius: 0,
    paddingHorizontal: 10,
    paddingVertical: 8,
  },
  skillText: {
    fontFamily: 'JetBrains Mono',
    fontSize: 12,
    fontWeight: '600',
  },
  achievementGrid: {
    gap: 12,
  },
  hobbyGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  hobbyChip: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 0,
    paddingHorizontal: 12,
    paddingVertical: 8,
    gap: 6,
  },
  hobbyIcon: {
    fontSize: 14,
  },
  hobbyText: {
    fontFamily: 'JetBrains Mono',
    fontSize: 12,
    fontWeight: '600',
  },
  socialRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  socialChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderRadius: 0,
    borderWidth: 1,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  socialText: {
    fontFamily: 'JetBrains Mono',
    fontSize: 12,
    fontWeight: '600',
  },
  analyticsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  footer: {
    borderTopWidth: 1,
    paddingTop: 20,
    paddingBottom: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
    gap: 12,
  },
  footerStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  footerText: {
    fontFamily: 'JetBrains Mono',
    fontSize: 9,
    letterSpacing: 0.8,
  },
  contactCard: {
    borderRadius: 0,
    borderWidth: 1,
    overflow: 'hidden',
  },
  contactInfo: {
    padding: 16,
  },
  contactFormDivider: {
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  contactForm: {
    padding: 16,
    gap: 12,
  },
  formLabel: {
    fontFamily: 'JetBrains Mono',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  formInput: {
    fontFamily: 'JetBrains Mono',
    borderRadius: 8,
    borderWidth: 1,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
  },
  formTextArea: {
    fontFamily: 'JetBrains Mono',
    borderRadius: 8,
    borderWidth: 1,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
    minHeight: 100,
    textAlignVertical: 'top',
  },
  submitButton: {
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
    marginTop: 8,
  },
  submitButtonText: {
    fontFamily: 'JetBrains Mono',
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  fab: {
    position: 'absolute',
    right: 20,
    bottom: 24,
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
  },
  fabText: {
    color: '#ffffff',
    fontSize: 26,
    fontWeight: '700',
    lineHeight: 26,
  },
});
